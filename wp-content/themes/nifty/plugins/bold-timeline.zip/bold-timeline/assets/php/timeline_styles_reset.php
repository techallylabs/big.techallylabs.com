<?php

$line_position	= '';
$line_style		= '';
$line_thickness = '';

$item_style	= '';
$item_shape	= '';
$item_frame_thickness	= '';

$item_connection_type = '';
$item_content_display = '';
$item_marker_type = '';
$item_title_size = '';
$item_supertitle_style = '';
$item_alignment = '';
$item_font_subset = '';
$item_media_position = '';
$item_images_columns = '';
$item_animation = '';
$item_icon_position = '';
$item_icon_shape = '';
$item_icon_style = '';

$group_frame_thickness = '';
$group_style = '';
$group_shape = '';
$group_title_size = '';
$group_font_subset = '';
$group_content_display = '';

$button_style = '';
$button_shape = '';
$button_size = '';
$button_color = '';

$slider_animation = '';
$slider_gap = '';
$slider_dots_style = '';
$slider_arrows_style = '';
$slider_arrows_shape = '';
$slider_arrows_size = '';
$slider_navigation_color = '';
$slider_slides_to_show = '';
$slider_auto_play = '';	